<?php
return array (
  'ver' => 'YunmV1.2',
);
?>